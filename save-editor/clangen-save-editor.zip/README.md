# clangen save editor

### [Discord Server](https://discord.gg/rnFQqyPZ7K) || [Itch.io Page](https://sablesteel.itch.io/clan-gen-fan-edit)

This is a barebones save editor for your Clan and cats.

Drop the folder in your main Clangen folder (so it is Clangen/save-editor).

Just double click "clangen_save_editor"! And back up your saves! 💙